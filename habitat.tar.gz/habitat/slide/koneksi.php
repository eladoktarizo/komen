<?php
$host1="localhost";
$user1="comment";
$pass1="ck_commentiiww";
//$user1="root";//"linux";
//$pass1="root";//"linux";
$conn = mysql_connect("$host1","$user1","$pass1");
mysql_select_db("comment", $conn);
?>
