<?php
$port="5432";
$host = "localhost";
$user = "root"
$pass = "root"
$db = "mapmaker";
?>
