<?php
$host = "localhost";
$user = "postgres";
//$pass = "12345";
$pass = "root@ck.ciptakarya.pu.go.id";//"root";//
$db = "onemap_spatial";//"mapmaker";
//$db = "mapmaker";
$port='5432';
$connect = pg_connect("host=$host port=$port dbname=$db user=$user password=$pass");
if($connect){
	//echo "terhubung";
}else{
	//echo "tidak terhubung";
}
?>